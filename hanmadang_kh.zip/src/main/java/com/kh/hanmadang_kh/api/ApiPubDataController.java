package com.kh.hanmadang_kh.api;


import com.kh.hanmadang_kh.svc.ApiPub;
import com.kh.hanmadang_kh.svc.Dbs;
import lombok.RequiredArgsConstructor;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/api/pub")
@RequiredArgsConstructor
public class ApiPubDataController {

    private final ApiPub apiExplorer;

    @GetMapping(value = "/json", produces = MediaType.APPLICATION_JSON_VALUE)
    public List<Dbs> getJsonData(){
        List<Dbs> res = apiExplorer.apiCall();
        return res;
    }


    @GetMapping(value = "/xml", produces = MediaType.APPLICATION_XML_VALUE)
    public  List<Dbs> getData(){
        List<Dbs> res = apiExplorer.apiCall();
        return res;
    }
}