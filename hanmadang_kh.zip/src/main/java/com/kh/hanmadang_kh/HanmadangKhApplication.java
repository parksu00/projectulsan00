package com.kh.hanmadang_kh;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HanmadangKhApplication {

	public static void main(String[] args) {
		SpringApplication.run(HanmadangKhApplication.class, args);
	}

}
