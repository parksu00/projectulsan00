package com.kh.hanmadang_kh.svc;

import java.util.List;

public interface ApiPub {
    List<Dbs> apiCall();
}
