package com.kh.hanmadang_kh;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HanmadangKhApplicationTests {

	@Test
	void contextLoads() {
	}

}
